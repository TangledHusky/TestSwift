//
//  K12PlayerView.swift
//  k12_sl_iOS
//
//  Created by 0 on 2017/9/26.
//
//

import UIKit
import MediaPlayer

protocol K12PlayerViewDelegate:NSObjectProtocol {
    func K12PlayerViewDidDismiss()
    func K12PlayerViewDidTap(isShow:Bool)
}
public enum vlcVideoActionType {
    case kuaijin    //快进
    case kuaitui    //快退
    case unknow     //未知
}

class K12PlayerView: UIView {
    
    //播放器
    lazy var player: VLCMediaPlayer = {
        let player = VLCMediaPlayer()
        player.delegate = self
        return player
    }()
    
    //底部控制
    lazy var contorll: K12ControllView = {
        let contorll = K12ControllView()
        return contorll
    }()
    
    
    var playerContainer = UIView()
    
    
    var delegate:K12PlayerViewDelegate?
    
    var barisShow = false
    
    var beginSliderValueWhenPan:Float = 0       //手势滑动时记录下的播放进度
    
    var originalHightness:CGFloat = 0         //原始亮度，视频退出后还原
    
     //视频标题
    var title:String = ""{
        didSet{
            if title.isEmpty {
                return
            }
            self.contorll.lblTitle.text = title
        }
    }
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        _init()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        _init()
    }

    
    
    private func _init(){
        self.backgroundColor = UIColor.black
        playerContainer.frame = self.bounds
        self.addSubview(playerContainer)
        
        
        contorll.frame = self.bounds
        contorll._initView()
        self.addSubview(contorll)
        
        contorll.playButton.addTarget(self, action: #selector(self.playClick), for: .touchUpInside)
        contorll.btnReplay.addTarget(self, action: #selector(self.replay), for: .touchUpInside)
        contorll.btnBack.addTarget(self, action: #selector(self.goBack), for: .touchUpInside)
        contorll.progressSlider.addTarget(self, action: #selector(timeChange), for: .valueChanged)
        contorll.progressSlider.addTarget(self, action: #selector(timeChange), for: .touchUpInside)
        
        
        
        contorll.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(panAction(gesture:))))
    }


    
    func setUpLocal(path: String){
        
        let media = VLCMedia(url: URL(fileURLWithPath: path))
        self.player.media = media
        beginPlay()
    }
    
    
    /// 开始播放
    func beginPlay(){
        
        self.player.drawable = self.playerContainer
        self.contorll.hideBarAfter()
        replay()
    }
    
    /// 重播
    func replay() {
        contorll.playButton.isSelected = false
        contorll.btnReplay.isHidden = true
        playClick()
        contorll.showBar()
    }
    
    
    /// 播放、暂停
    func playClick(){
        contorll.playButton.isSelected = !contorll.playButton.isSelected
        //选中是播放
        if contorll.playButton.isSelected {
            self.player.play()
            self.contorll.btnReplay.isHidden = true
            self.contorll.hideBarAfter()
        }else{
            self.player.pause()
            self.contorll.cancelhideBarAfter()
        }
        
    }
    
    
    
  
    func timeChange(){
        
        let value = self.contorll.progressSlider.value
        setNewPlay(nowVlaue: value)
    }
    
    func setNewPlay(nowVlaue:Float) {
  
        //设置当前视频时间
        let time = Float(self.player.media.length.intValue) * nowVlaue
        let vlctime = VLCTime.init(int: Int32.init(time))!
        self.player.time = vlctime
        self.contorll.hideBarAfter()
        
        //如果播放结束了，拉动进度条，继续播放
        if self.contorll.btnReplay != nil && self.contorll.btnReplay.isHidden == false {
            self.contorll.playButton.isSelected = true
            self.contorll.btnReplay.isHidden = true
            self.player.play()
            
        }
        
        // 实时更新时间
        self.contorll.timeLable.text = String(format: "%@", player.time.stringValue)
        
        //如果是手势进度，更新label
        if self.contorll.lblShowSliderTime.isHidden == false {
            self.contorll.lblShowSliderTime.text = self.contorll.timeLable.text
        }
        
       
    }
    
    
    /// <#Description#>
    ///
    /// - Parameter addValue: 快进是正数
    func setSliderWhenPan(addValue:Float) {
        var newValue:Float = 0.0
        if addValue < 0 {
            newValue = max(0, beginSliderValueWhenPan + addValue)
        }else{
            newValue = min(1, beginSliderValueWhenPan + addValue)
        }
        
        setNewPlay(nowVlaue: newValue)
    }
    
    override func layoutSubviews() {
        self.contorll.frame = self.bounds
        self.contorll.layoutSubviews()
    }
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        if touches.count > 0 {
            DispatchQueue.main.async { [weak self] in
                self?.responseTap()
            }
        }
    }

    func panAction(gesture: UIPanGestureRecognizer){
        let point = gesture.location(in: self)
        let direct = gesture.velocity(in: self)

        switch gesture.state {
        case UIGestureRecognizerState.began:
            beginSliderValueWhenPan = self.contorll.progressSlider.value
            break
        case UIGestureRecognizerState.changed:
            
            //判断方向
            if fabs(direct.x) > fabs(direct.y) {
                //水平滑动
                if  point.y < self.bounds.height/4 ||  point.y > self.bounds.height/4*3{
                    return
                }
                
                
                if self.contorll.lblShowSliderTime.isHidden == true{
                    self.contorll.lblShowSliderTime.isHidden = false
                    self.contorll.lblShowSliderTime.frame = CGRect(x: 0, y: 0, width: 200, height: 60)
                    self.contorll.lblShowSliderTime.center = CGPoint(x: KScreenWidth/2, y: KScreenHeight/4)
                }

                //水平移动 调整进度  gesture.translation(in: self).x > 0表示快进
                let jindu:Float = Float(gesture.translation(in: self).x/KScreenWidth)
                setSliderWhenPan(addValue: jindu)
                
            }else{
                //垂直滑动
                if point.x < KScreenWidth/4 || point.x > KScreenWidth/4*3{
                    return
                }

                if point.x > self.bounds.width/2 {
                    // 改变音量（y>0 往下滑）
                    if gesture.translation(in: self).y > 0{
                        self.contorll.volumeSlider.value -= 0.03
                    }else{
                        self.contorll.volumeSlider.value += 0.03
                    }
                    
                }else{
                    // 改变显示亮度
                    if originalHightness == 0{
                        originalHightness = UIScreen.main.brightness
                    }
                    
                    if gesture.translation(in: self).y > 0{
                        UIScreen.main.brightness -= 0.01
                    }else{
                        UIScreen.main.brightness += 0.01
                    }
                }
            }
            
            break
        case UIGestureRecognizerState.ended:
            self.contorll.lblShowSliderTime.isHidden = true
            beginSliderValueWhenPan = 0
            break
        default:
            break
        }
        
    }
    
    func responseTap(){
        barisShow = !barisShow
        !barisShow ? self.contorll.showBar() : self.contorll.hideBar()
    }
    
    func readyClose() {
        self.contorll.removeFromSuperview()
        self.player.stop()
    }
    
    
    /// 关闭
    func dismiss() {
        //还原pad亮度
        if originalHightness != 0 {
            UIScreen.main.brightness = originalHightness
        }
        
        readyClose()
        weak var weakself = self
        UIView.animate(withDuration: 0.7, animations: {
            weakself?.alpha = 0
            weakself?.transform  = CGAffineTransform(scaleX: 0.1, y: 0.1)
            
        }) { (flag) in
            weakself?.removeFromSuperview()
        }
        
    }
    
    func goBack() {
        self.delegate?.K12PlayerViewDidDismiss()
    }
}


// MARK: - 视频播放
extension K12PlayerView: VLCMediaPlayerDelegate {
    
    func mediaPlayerStateChanged(_ aNotification: Notification!) {
        
        if self.player.state == .error{
            print("视频播放错误")
        }else if self.player.state == .ended{
            self.contorll.btnReplay.isHidden = false
            self.player.stop()
            self.contorll.showBar(isDismiss: false)
            self.contorll.playButton.isSelected = false
            self.contorll.progressSlider.value = 1.0
            self.contorll.timeLable.text = self.contorll.timeEndLable.text
        }else if self.player.state == .paused{
            self.contorll.progressSlider.value = Float(self.player.time.intValue) / Float(self.player.media.length.intValue)
        }
    }
    
    func mediaPlayerTimeChanged(_ aNotification: Notification!) {

        if self.contorll.progressSlider.state.rawValue == 1 {
            return
        }
        
        let percent = Float(self.player.time.intValue) / Float(self.player.media.length.intValue)
        
        self.contorll.progressSlider.setValue(percent, animated: true)
        self.contorll.timeLable.text = String(format: "%@", player.time.stringValue)
        self.contorll.timeEndLable.text = String(format: "%@", self.player.media.length.stringValue)
        
        
    }
    
    
    
    
}





/// 视频覆盖控制器
class K12ControllView: UIView
{
    var topBar: UIView!
    var btnBack:UIButton!
    var lblTitle:UILabel!
    
    var btnReplay:UIButton!
    
    
    var bottomBar: UIView!
    var playButton: UIButton!
    var progressSlider: DBSlider!
    
    var timeLable: UILabel!
    var timeEndLable: UILabel!
    var volumeView: MPVolumeView!
    var volumeSlider: UISlider!
    
    var topBarHeight:CGFloat = 60
    var bottomBarHeight:CGFloat = 50
    
    lazy var lblShowSliderTime:UILabel = {
        let lbl = UILabel()
        lbl.textColor = UIColor.white
        lbl.font = UIFont.systemFont(ofSize: 55)
        lbl.layer.cornerRadius = 10
        lbl.layer.backgroundColor = UIColor.black.withAlphaComponent(0.7).cgColor
        lbl.textAlignment = .center
        lbl.isHidden = true
        self.addSubview(lbl)
        return lbl
        
    }()
  
    
    func _initView(){
        self.backgroundColor = UIColor.clear
        
        
        //头部bar
        topBar = UIView()
        self.addSubview(topBar)
        topBar.backgroundColor = UIColor.clear
        
        btnBack = UIButton()
        btnBack.setTitle("返回", for: .normal)
        btnBack.setTitleColor(UIColor.white, for: .normal)
        btnBack.titleLabel?.font = UIFont.systemFont(ofSize: 22)
        self.addSubview(btnBack)
        
        lblTitle = UILabel()
        lblTitle.font = UIFont.systemFont(ofSize: 18)
        lblTitle.textColor = UIColor.white
        lblTitle.textAlignment = .center
        topBar.addSubview(lblTitle)
        
        
        //重播按钮
        btnReplay = UIButton(frame: CGRect(x: 0, y: 0, width: 100, height: 100))
        btnReplay.center = self.center
        btnReplay.backgroundColor = UIColor.clear
        btnReplay.setImage(UIImage(named: "replay"), for: .normal)
        btnReplay.setTitle("重播", for: .normal)
        btnReplay.titleLabel?.font = UIFont.systemFont(ofSize: 18)
        btnReplay.titleEdgeInsets = UIEdgeInsets(top: (btnReplay.imageView?.frame.height)!, left: -(btnReplay.imageView?.frame.width)!, bottom: 0, right: 0)
        btnReplay.imageEdgeInsets = UIEdgeInsets(top: -(btnReplay.titleLabel?.frame.height)! - 20, left: 0, bottom: 0, right: -(btnReplay.titleLabel?.frame.width)!)
        btnReplay.isHidden = true
        btnReplay.setTitleColor(UIColor.white, for: .normal)
        self.addSubview(btnReplay)
        
        
        //底部bar
        bottomBar = UIView()
        bottomBar.backgroundColor = UIColor.clear
        playButton = UIButton(type: .custom)
        playButton.setImage(UIImage(named: "play"), for: .normal)
        playButton.setImage(UIImage(named: "pause"), for: .selected)
        playButton.isSelected = true
        
        progressSlider = DBSlider()
        progressSlider.setThumbImage(UIImage(named: "Player Control Nob") , for: .normal)
        progressSlider.minimumTrackTintColor = UIColor(red: 239/255, green: 71/255, blue: 94/255, alpha: 1)
        progressSlider.maximumTrackTintColor = UIColor(red: 157/255, green: 157/255, blue: 157/255, alpha: 1)
        progressSlider.backgroundColor = UIColor.clear
        progressSlider.value = 0
        progressSlider.isContinuous = false
        
        
        timeLable = UILabel()
        timeLable.backgroundColor = UIColor.clear
        timeLable.font = UIFont.systemFont(ofSize: 12)
        timeLable.textColor = UIColor.lightGray
        timeLable.textAlignment = .center
        timeLable.bounds = CGRect(x: 0, y: 0, width: 15, height: bottomBarHeight)
        timeLable.text = "00:00"
        
        timeEndLable = UILabel()
        timeEndLable.backgroundColor = UIColor.clear
        timeEndLable.font = UIFont.systemFont(ofSize: 12)
        timeEndLable.textColor = UIColor.lightGray
        timeEndLable.textAlignment = .center
        timeEndLable.bounds = CGRect(x: 0, y: 0, width: 15, height: bottomBarHeight)
        timeEndLable.text = "00:00"
        
        volumeView = MPVolumeView()
        for view in volumeView.subviews {
            if view.superclass != nil && view.superclass!.isSubclass(of: UISlider.classForCoder()) {
                volumeSlider = view as! UISlider
            }
        }
        
        
        self.addSubview(bottomBar)
        self.bottomBar.addSubview(playButton)
        self.bottomBar.addSubview(progressSlider)
        self.bottomBar.addSubview(timeLable)
        self.bottomBar.addSubview(timeEndLable)

        
        self.bottomBar.isUserInteractionEnabled = true
    }
    
    
    
   
    
    
    override func layoutSubviews() {
        super.layoutSubviews()
        
        self.topBar.frame = CGRect(x: self.bounds.minX, y: 0, width: self.bounds.width, height: topBarHeight)
        btnBack.frame = CGRect(x: 5, y: 5, width: 60, height: topBarHeight)
        lblTitle.frame = CGRect(x: btnBack.frame.maxX, y: 0, width: self.bounds.width - btnBack.frame.maxX*2, height: topBar.frame.height)
        
        self.bottomBar.frame = CGRect(x: self.bounds.minX, y: self.bounds.height - bottomBarHeight, width: self.bounds.width, height: bottomBarHeight)
        playButton.frame = CGRect(x: 10, y: 0, width: 50, height: bottomBarHeight)
        timeLable.frame = CGRect(x: 60 , y:0, width: 70, height: bottomBar.bounds.height)
        progressSlider.frame = CGRect(x: 130, y: (bottomBarHeight-10)/2, width: self.bounds.width - timeLable.frame.maxX - 70, height: 10)
        timeEndLable.frame = CGRect(x: bottomBar.frame.width - 70 , y:0, width: 60, height: bottomBar.bounds.height)
    }
    
    
    
    
    func hideBar(){
        UIView.animate(withDuration: 0.3) {
            self.bottomBar.alpha = 0.0
            self.topBar.alpha = 0.0
            self.btnBack.alpha = 0.5
        }
    }
    
    //状态栏自动消失，需要的话放开下面两段代码即可
    func hideBarAfter(){
        //        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(hideBar), object: nil)
        //        self.perform(#selector(hideBar), with: nil, afterDelay: 7)
    }
    
    func cancelhideBarAfter(){
        //        NSObject.cancelPreviousPerformRequests(withTarget: self, selector: #selector(hideBar), object: nil)
    }
    
    func showBar(isDismiss:Bool = true){
        weak var weakself = self
        UIView.animate(withDuration: 0.3, animations: {
            weakself?.bottomBar.alpha = 1
            weakself?.topBar.alpha = 1
            weakself?.btnBack.alpha = 1
        }) { (ifFinish) in
            if isDismiss{
                weakself?.hideBarAfter()
            }
        }
    }
}



