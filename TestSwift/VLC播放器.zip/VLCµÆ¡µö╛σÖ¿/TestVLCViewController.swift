//
//  TestVLCViewController.swift
//  TestSwift
//
//  Created by liyajun on 2017/10/25.
//  Copyright © 2017年 YJ公司. All rights reserved.
//

import UIKit

class TestVLCViewController: UIViewController {

    // 视频播放器(vlc)
    var k12Player: K12PlayerView! = nil
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = UIColor.white
        

        let btnplay = UIButton(frame: CGRect(x: 0, y: 0, width: KScreenWidth, height: 50))
        btnplay.center = view.center
        btnplay.setTitle("点击播放", for: .normal)
        btnplay.setTitleColor(UIColor.black, for: .normal)
        btnplay.titleLabel?.font = UIFont.systemFont(ofSize: 25)
        btnplay.addTarget(self, action: #selector(self.initVC), for: .touchUpInside)
        self.view.addSubview(btnplay)
    }

    func initVC() {
        let path = Bundle.main.path(forResource: "20171024164306", ofType: "mp4")
        if path != nil {
            k12Player = K12PlayerView(frame: CGRect(x: 0, y: 0, width: KScreenWidth, height: KScreenHeight))
            k12Player.delegate = self
            k12Player.title = "video title"
            k12Player.setUpLocal(path: path!)
            self.view.addSubview(k12Player)
        }
    }
    
    

}

extension TestVLCViewController:K12PlayerViewDelegate{
    /// 视频返回
    func K12PlayerViewDidDismiss() {
        k12Player.dismiss()
        k12Player = nil
    }
    
    /// 点击屏幕中间(比如可以控制隐藏工具栏和状态栏)
    func K12PlayerViewDidTap(isShow: Bool) {
        print("tap player screen")
        
    }
}
